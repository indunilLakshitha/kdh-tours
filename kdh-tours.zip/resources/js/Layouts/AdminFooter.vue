<template>
    <div class="admin-footer">&nbsp;</div>
</template>

<script>
    export default {};
</script>
