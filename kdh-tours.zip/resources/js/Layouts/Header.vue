<template>
    <nav class="header">
        <img :src="'/images/logo.png'" alt="" class="logo" />
    </nav>
</template>

<script>
export default {};
</script>
