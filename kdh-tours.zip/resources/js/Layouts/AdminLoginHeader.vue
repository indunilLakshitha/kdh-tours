<template>
    <nav class="header">
        <img :src="'/images/logo.png'" alt="" class="logo" />
        <div class="admin-title">Management screen</div>
    </nav>
</template>

<script>
    export default {};
</script>