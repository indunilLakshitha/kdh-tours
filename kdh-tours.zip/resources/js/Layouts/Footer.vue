<template>
    <div class="footer">プライバシーポリシー　/　　運営会社</div>
</template>

<script>
    export default {};
</script>
