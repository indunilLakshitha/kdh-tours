<?php

return [


    /*
    |--------------------------------------------------------------------------
    | Default No Image
    |--------------------------------------------------------------------------
    */
    'noimage' => base_path().'/public/images/noimage.jpg',

    /*
    |--------------------------------------------------------------------------
    | Documents Image Path
    |--------------------------------------------------------------------------
    */
    'doc_images_root_path' => storage_path().'/app/public/images/document/',
    'doc_images_root_url' => ('storage/images/document')."/",
];
