<?php
return [

    'email_url'=>'http://127.0.0.1:8000',
    // 'live_url'=>'http://3.20.96.227'
    'live_url'=>'http://3.20.96.227'
    // 'live_url'=>'http://service-monitor.bizeyes.jp'
];
